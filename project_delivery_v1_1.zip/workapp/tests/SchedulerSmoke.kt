import ir.coke.discharge.*

private fun scenario(n: Int, d: Int, gapIndex: Int, cycle: Int, period: Long = 38L * 60L) {
    val shiftStart = 2_000_000L
    val first = 101
    val cells = chain(first, n)
    val ideals = mutableMapOf<Int, Long>()
    var offset = 0L
    cells.forEachIndexed { i, cell ->
        if (i > 0) offset += if (i - 1 == gapIndex) cycle.toLong() else d.toLong()
        ideals[cell] = shiftStart + offset
    }
    val charges = ideals.mapValues { it.value - period }
    val plan = buildPlan(shiftStart, n, d, period, charges, first, 120)
    check(plan.error == null) { plan.error ?: "unknown" }
    check(plan.rows.size == n) { "wrong event count" }
    check(plan.rows.first().planMin >= shiftStart) { "plan before shift start" }
    check(plan.rows.last().planMin <= shiftStart + 460) { "plan after 460-minute shift" }
    check(plan.cycleMin >= 60) { "maintenance cycle < 60" }
    check(plan.maxDev == 0) { "expected zero deviation; got ${plan.maxDev}" }
    check(plan.rows.map { it.cell } == chain(first, n)) { "five-cell order violated" }
    check(plan.cycleAfter == gapIndex) { "unexpected cycle position ${plan.cycleAfter}" }
}

fun main() {
    // مثال کاربر: ۲۹ تخلیه، فاصله ۱۴ دقیقه، سیکل ۸۲ دقیقه؛ دقیقاً ۴۶۰ دقیقه.
    scenario(n = 29, d = 14, gapIndex = 10, cycle = 82)
    scenario(n = 19, d = 20, gapIndex = 8, cycle = 100)
    scenario(n = 14, d = 25, gapIndex = 5, cycle = 160)

    val n = 29
    val start = 2_000_000L
    val cells = chain(101, n)
    val charges = cells.associateWith { start - 38L * 60L }
    val invalidGap = buildPlan(start, n, 9, 38L * 60L, charges, 101, 120)
    check(invalidGap.error?.contains("۱۰ دقیقه") == true)

    // برای ۲۹ تخلیه، d=15 فقط ۵۵ دقیقه برای سیکل باقی می‌گذارد؛ d=14، سیکل ۸۲ دقیقه‌ای می‌دهد.
    val idealCharges = mutableMapOf<Int, Long>()
    var off = 0L
    cells.forEachIndexed { i, cell ->
        if (i > 0) off += if (i - 1 == 10) 82L else 14L
        idealCharges[cell] = start + off - 38L * 60L
    }
    val tooWide = buildPlan(start, n, 15, 38L * 60L, idealCharges, 101, 120)
    check(tooWide.error != null)
    val (suggestions, error) = suggestD(start, n, 38L * 60L, idealCharges, 101, 120, 10, 90)
    check(suggestions.isNotEmpty()) { error ?: "no suggestion" }
    check(suggestions.first().d == 14) { "expected d=14, got ${suggestions.first().d}" }
    check(suggestions.first().plan.cycleMin >= 60)

    // ساعت شروع واقعی؛ پایان کار ۴۶۰ دقیقه بعد و فاصله تعویض ۲۰ دقیقه است.
    check(shiftStartMinute(16L * 60, ShiftKind.NIGHT) == 23 * 60)
    check(shiftStartMinute(25L * 60, ShiftKind.DAY) == 7 * 60)
    check(shiftStartMinute(26L * 60, ShiftKind.EVENING) == 14 * 60 + 20)
    check((shiftStartMinute(38L * 60, ShiftKind.NIGHT) + Rules.SHIFT_MIN) % 1440 == 6 * 60)
    check((shiftStartMinute(38L * 60, ShiftKind.DAY) + Rules.SHIFT_MIN) % 1440 == 14 * 60)
    check((shiftStartMinute(38L * 60, ShiftKind.EVENING) + Rules.SHIFT_MIN) % 1440 == 22 * 60)
    fun modDay(v: Int) = v % 1440
    // ۱۶ تا ۲۵ ساعت: پایان کار تا شروع شیفت بعدی دقیقاً ۲۰ دقیقه فاصله دارد.
    check(modDay(shiftStartMinute(20L * 60, ShiftKind.DAY) + Rules.SHIFT_MIN + Rules.HANDOVER_MIN) == 15 * 60)
    check(modDay(shiftStartMinute(20L * 60, ShiftKind.EVENING) + Rules.SHIFT_MIN + Rules.HANDOVER_MIN) == 23 * 60)
    check(modDay(shiftStartMinute(20L * 60, ShiftKind.NIGHT) + Rules.SHIFT_MIN + Rules.HANDOVER_MIN) == 7 * 60)
    // بالاتر از ۲۵ ساعت: همین فاصله ۲۰ دقیقه‌ای با ساعت‌های جابه‌جا شده حفظ می‌شود.
    check(modDay(shiftStartMinute(38L * 60, ShiftKind.DAY) + Rules.SHIFT_MIN + Rules.HANDOVER_MIN) == 14 * 60 + 20)
    check(modDay(shiftStartMinute(38L * 60, ShiftKind.EVENING) + Rules.SHIFT_MIN + Rules.HANDOVER_MIN) == 22 * 60 + 20)
    check(modDay(shiftStartMinute(38L * 60, ShiftKind.NIGHT) + Rules.SHIFT_MIN + Rules.HANDOVER_MIN) == 6 * 60 + 20)
    check(Rules.SHIFT_MIN == 460 && Rules.HANDOVER_MIN == 20)

    // حتی با حداقل فاصله، اگر ۵۸ تخلیه و سیکل ۶۰ دقیقه جا نشوند، عدم امکان گزارش شود.
    val impossible = suggestD(start, 58, 38L * 60L, charges, 101, 120, 10, 90)
    check(impossible.first.isEmpty() && impossible.second != null)

    println("PASS: 460-minute work window, 20-minute handover outside shift, 10-minute minimum gap, 14-minute optimized gap, 60-minute maintenance, shift starts/ends, five-cell order, and infeasibility reporting")
}
