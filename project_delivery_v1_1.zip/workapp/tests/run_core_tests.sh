#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${ROOT}/.test-build"
mkdir -p "$OUT"
kotlinc "$ROOT/app/src/main/java/ir/coke/discharge/Scheduler.kt" "$ROOT/tests/SchedulerSmoke.kt" -include-runtime -d "$OUT/scheduler-smoke.jar"
java -jar "$OUT/scheduler-smoke.jar"
kotlinc "$ROOT/app/src/main/java/ir/coke/discharge/Scheduler.kt" "$ROOT/tests/FuzzSmoke.kt" -include-runtime -d "$OUT/fuzz-smoke.jar"
java -jar "$OUT/fuzz-smoke.jar"
kotlinc "$ROOT/app/src/main/java/ir/coke/discharge/Scheduler.kt" "$ROOT/app/src/main/java/ir/coke/discharge/Dates.kt" -d "$OUT/core.jar"
echo "CORE COMPILE PASS"
