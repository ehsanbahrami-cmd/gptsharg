import ir.coke.discharge.*
import kotlin.random.Random

fun main() {
    val random = Random(42)
    val shift = 4_000_000L
    var tested = 0
    for (n in 4..58) {
        val maxD = (Rules.USABLE - Rules.MIN_CYCLE) / (n - 2)
        if (maxD < Rules.MIN_GAP) continue
        val d = random.nextInt(Rules.MIN_GAP, maxD + 1)
        val cycle = random.nextInt(Rules.MIN_CYCLE, Rules.USABLE - (n - 2) * d + 1)
        val gap = random.nextInt(0, n - 1)
        val cells = chain(101, n)
        var off = 0L
        val charges = mutableMapOf<Int, Long>()
        cells.forEachIndexed { i, c ->
            if (i > 0) off += if (i - 1 == gap) cycle.toLong() else d.toLong()
            val ideal = shift + off + random.nextInt(-25, 26)
            charges[c] = ideal - 38L * 60L
        }
        val plan = buildPlan(shift, n, d, 38L * 60L, charges, 101, 120)
        check(plan.error == null) { "n=$n d=$d error=${plan.error}" }
        check(plan.rows.size == n)
        check(plan.rows.all { it.planMin in shift..(shift + 460) })
        check(plan.cycleMin >= 60)
        check(plan.rows.zipWithNext().all { it.second.planMin > it.first.planMin })
        check(plan.rows.map { it.cell } == chain(101, n))
        tested++
    }
    println("FUZZ PASS: $tested combinations (n=4..58), all inside exact 460-minute shift, ordered, and cycle >=60")
}
