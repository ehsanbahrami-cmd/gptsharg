package ir.coke.discharge

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** قوانین ثابت باتری */
object Rules {
    const val TOTAL = 1392.0      // 58 سلول × 24 ساعت
    const val FIRST = 101
    const val COUNT = 58
    const val STEP = 5
    const val SHIFT_MIN = 460       // مدت واقعی کار در هر شیفت: ۷ ساعت و ۴۰ دقیقه
    const val HANDOVER_MIN = 20     // فاصله تعویض شیفت؛ خارج از بازه عملیاتی
    const val USABLE = SHIFT_MIN    // کل ۴۶۰ دقیقه برای تخلیه و سیکل قابل استفاده است
    const val MIN_CYCLE = 60
    const val MIN_GAP = 10
    const val LEGAL = 30
}

enum class ShiftKind(val fa: String) {
    NIGHT("شب"), DAY("روز"), EVENING("عصر")
}

/**
 * ساعت شروع واقعی کار بر اساس پریود تولید.
 * تاریخ ورودی در شیفت شب، تاریخ پایان کار (صبح) است؛ شروع در روز قبل قرار می‌گیرد.
 * شیفت ۴۶۰ دقیقه کار دارد و ۲۰ دقیقه بعدی فقط فاصله تعویض شیفت است.
 */
fun shiftStartMinute(periodMin: Long, kind: ShiftKind): Int {
    val longPeriod = periodMin > 25L * 60L
    return when (kind) {
        ShiftKind.NIGHT -> if (longPeriod) 22 * 60 + 20 else 23 * 60
        ShiftKind.DAY -> if (longPeriod) 6 * 60 + 20 else 7 * 60
        ShiftKind.EVENING -> if (longPeriod) 14 * 60 + 20 else 15 * 60
    }
}

fun cellsPerDay(periodHours: Double): Int = ceil(Rules.TOTAL / periodHours - 1e-9).toInt()

/** کمترین به روز، بعد شب، بعد عصر */
fun shiftCount(n: Int, k: ShiftKind): Int {
    val b = n / 3
    val r = n % 3
    return when (k) {
        ShiftKind.DAY -> b
        ShiftKind.NIGHT -> b + if (r == 2) 1 else 0
        ShiftKind.EVENING -> b + if (r >= 1) 1 else 0
    }
}

fun nextCell(c: Int): Int = Rules.FIRST + (c - Rules.FIRST + Rules.STEP) % Rules.COUNT

fun chain(start: Int, n: Int): List<Int> {
    val out = ArrayList<Int>()
    var c = start
    repeat(n) { out.add(c); c = nextCell(c) }
    return out
}

data class Row(
    val cell: Int,
    val chargeMin: Long,
    val idealMin: Long,
    val planMin: Long,
) {
    val periodMin get() = planMin - chargeMin
    val devMin get() = planMin - idealMin
}

data class Mismatch(val cell: Int, val chargeMin: Long, val idealMin: Long)

enum class Note { OK, CYCLE_REDUCED, EARLY, LATE, BOTH }

data class Plan(
    val rows: List<Row> = emptyList(),
    val n: Int = 0,
    val q: Int = 0,
    val cycleAfter: Int = 0,
    val nominalCycle: Int = 0,
    val note: Note = Note.OK,
    val maxDev: Int = 0,
    val shiftStart: Long = 0,
    val skipped: List<Int> = emptyList(),
    val mismatch: List<Mismatch> = emptyList(),
    val error: String? = null,
    val totalAbsDev: Long = 0,
    val cycleStartError: Int = 0,
) {
    val cycleMin: Long get() = if (rows.size > cycleAfter + 1) rows[cycleAfter + 1].planMin - rows[cycleAfter].planMin else 0
}

data class Suggestion(val d: Int, val plan: Plan, val violation: Int)

private data class Candidate(
    val plan: Plan,
    val maxAbs: Long,
    val totalAbs: Long,
    val totalSquared: Long,
    val cycleStartError: Long,
)

/**
 * زمان‌ها بر حسب دقیقه epoch هستند.
 * پنجره مجاز برنامه‌ریزی کل ۴۶۰ دقیقه کار شیفت است؛ ۲۰ دقیقه تعویض شیفت خارج از آن است.
 * بین n تخلیه، n-2 فاصله عادی d و یک فاصله سیکل تعمیراتی (حداقل ۶۰ دقیقه) وجود دارد.
 * فاصله عادی d در تمام برنامه یکنواخت است و موتور آن را از حداقل ۱۰ دقیقه به بالا بررسی می‌کند.
 */
fun buildPlan(
    shiftStart: Long, n: Int, d: Int, periodMin: Long,
    charges: Map<Int, Long>, startCell: Int?, cycleOffset: Int,
): Plan {
    fun err(m: String) = Plan(error = m, shiftStart = shiftStart)
    if (n < 4 || n > Rules.COUNT) return err("تعداد سلول شیفت نامعتبر است")
    if (d < Rules.MIN_GAP) return err("فاصله تخلیه نمی‌تواند کمتر از ۱۰ دقیقه باشد")

    val start: Int = startCell ?: run {
        charges.entries.filter { it.value + periodMin >= shiftStart - 90 }
            .minByOrNull { it.value }?.key
    } ?: return err("سلولی برای این شیفت پیدا نشد؛ زمان شارژها را وارد کنید")
    if (start !in Rules.FIRST until Rules.FIRST + Rules.COUNT) return err("شماره سلول شروع نامعتبر است")

    val cells = chain(start, n)
    val missing = cells.filter { charges[it] == null }
    if (missing.isNotEmpty()) return err("زمان شارژ این سلول‌ها وارد نشده: " + missing.joinToString("، "))

    val ideal = cells.map { charges[it]!! + periodMin }
    val s = shiftStart
    val usableStart = s
    val usableEnd = s + Rules.SHIFT_MIN
    val bad = cells.indices.filter { ideal[it] < s - 360 || ideal[it] > s + Rules.SHIFT_MIN + 360 }
        .map { Mismatch(cells[it], charges[cells[it]]!!, ideal[it]) }
    if (bad.isNotEmpty()) return Plan(error = "تاریخ شارژ و پریود با شیفت انتخابی متناسب نیست", mismatch = bad, shiftStart = s)

    val q = n - 2
    val maxD = (Rules.USABLE - Rules.MIN_CYCLE) / q
    if (d > maxD) return err("فاصله $d دقیقه‌ای با سیکل حداقل ۶۰ دقیقه در این شیفت جا نمی‌شود؛ حداکثر فاصله مجاز ${maxD} دقیقه است")

    val maxCycle = Rules.USABLE - q * d
    val preferredGap = (cycleOffset.toDouble() / d).roundToInt().coerceIn(0, n - 2)
    var best: Candidate? = null

    // همه طول‌های ممکن سیکل و تمام محل‌های ممکن سیکل بررسی می‌شوند.
    for (cycle in Rules.MIN_CYCLE..maxCycle) {
        for (gapIndex in 0 until n - 1) {
            val offsets = LongArray(n)
            for (i in 1 until n) {
                offsets[i] = offsets[i - 1] + if (i - 1 == gapIndex) cycle.toLong() else d.toLong()
            }
            val latestFirst = usableEnd - offsets.last()
            if (latestFirst < usableStart) continue

            // x0 باید موعدهای تمام سلول‌ها را تا حد ممکن به موعد ایده‌آل نزدیک کند.
            val residuals = LongArray(n) { ideal[it] - offsets[it] }
            val minR = residuals.minOrNull()!!
            val maxR = residuals.maxOrNull()!!
            val low = max(usableStart, maxR - Rules.LEGAL)
            val high = min(latestFirst, minR + Rules.LEGAL)
            val unconstrained = residuals.sorted()[n / 2] // میانه، کمینه‌کننده مجموع قدرمطلق
            val x0 = if (low <= high) unconstrained.coerceIn(low, high)
                     else ((minR + maxR) / 2L).coerceIn(usableStart, latestFirst)

            val deviations = LongArray(n) { x0 + offsets[it] - ideal[it] }
            val maxAbs = deviations.maxOf { abs(it) }
            val totalAbs = deviations.sumOf { abs(it) }
            val totalSquared = deviations.sumOf { it * it }
            val actualCycleStartOffset = (x0 + offsets[gapIndex] - s).toInt()
            val targetCycleStartOffset = cycleOffset.coerceAtLeast(0)
            val cycleStartError = abs(actualCycleStartOffset - targetCycleStartOffset).toLong()
            val rows = cells.indices.map { i -> Row(cells[i], charges[cells[i]]!!, ideal[i], x0 + offsets[i]) }
            val nominal = maxCycle
            val note = when {
                maxAbs > Rules.LEGAL && deviations.any { it < -Rules.LEGAL } && deviations.any { it > Rules.LEGAL } -> Note.BOTH
                maxAbs > Rules.LEGAL && deviations.any { it < -Rules.LEGAL } -> Note.EARLY
                maxAbs > Rules.LEGAL && deviations.any { it > Rules.LEGAL } -> Note.LATE
                cycle < nominal -> Note.CYCLE_REDUCED
                else -> Note.OK
            }
            val skipped = charges.filter { (c, v) -> c !in cells && v + periodMin <= usableEnd }.keys.sorted()
            val p = Plan(
                rows = rows, n = n, q = q, cycleAfter = gapIndex, nominalCycle = nominal,
                note = note, maxDev = maxAbs.toInt(), shiftStart = s, skipped = skipped,
                totalAbsDev = totalAbs, cycleStartError = cycleStartError.toInt()
            )
            val candidate = Candidate(p, maxAbs, totalAbs, totalSquared, abs(gapIndex - preferredGap).toLong() * d + cycleStartError)
            val old = best
            if (old == null || compareCandidate(candidate, old) < 0) best = candidate
        }
    }

    val chosen = best?.plan ?: return err("با رعایت فاصله حداقل ۱۰ دقیقه، سیکل تعمیراتی حداقل ۶۰ دقیقه و محدودیت ۴۶۰ دقیقه کار در همین شیفت، برنامه امکان‌پذیر نیست. تعداد تخلیه یا شرایط شیفت باید توسط اپراتور بازبینی شود.")
    return chosen
}

/** اول کمترین تخطی از قانون پریود، سپس کمترین مجموع انحراف؛ بعد توزیع مناسب سیکل. */
private fun compareCandidate(a: Candidate, b: Candidate): Int {
    val aViolation = max(0L, a.maxAbs - Rules.LEGAL)
    val bViolation = max(0L, b.maxAbs - Rules.LEGAL)
    if (aViolation != bViolation) return aViolation.compareTo(bViolation)
    if (a.maxAbs != b.maxAbs) return a.maxAbs.compareTo(b.maxAbs)
    if (a.totalAbs != b.totalAbs) return a.totalAbs.compareTo(b.totalAbs)
    if (a.totalSquared != b.totalSquared) return a.totalSquared.compareTo(b.totalSquared)
    if (a.cycleStartError != b.cycleStartError) return a.cycleStartError.compareTo(b.cycleStartError)
    // در تساوی کامل، سیکل طولانی‌تر ترجیح داده می‌شود.
    return b.plan.cycleMin.compareTo(a.plan.cycleMin)
}

/** بهترین فاصله از ۱۰ دقیقه تا بیشترین مقدار ممکن بررسی می‌شود؛ فاصله ثابت از پیش تحمیل نمی‌شود. */
fun suggestD(
    shiftStart: Long, n: Int, periodMin: Long, charges: Map<Int, Long>,
    startCell: Int?, cycleOffset: Int, dMin: Int, cycWant: Int,
): Pair<List<Suggestion>, String?> {
    if (n < 4 || n > Rules.COUNT) return Pair(emptyList(), "تعداد سلول شیفت نامعتبر است")
    val minGap = max(Rules.MIN_GAP, dMin)
    val maxGap = (Rules.USABLE - Rules.MIN_CYCLE) / (n - 2)
    if (minGap > maxGap) {
        val required = (n - 2) * minGap + Rules.MIN_CYCLE
        val shortage = required - Rules.USABLE
        return Pair(
            emptyList(),
            "برای $n تخلیه، با حداقل فاصله $minGap دقیقه و سیکل تعمیراتی حداقل ۶۰ دقیقه، دست‌کم $required دقیقه لازم است؛ ظرفیت کار این شیفت ۴۶۰ دقیقه است و $shortage دقیقه کمبود زمان وجود دارد. برنامه معتبر ساخته نشد؛ تصمیم با اپراتور است."
        )
    }

    val list = ArrayList<Suggestion>()
    var firstErr: String? = null
    for (d in minGap..maxGap) {
        val p = buildPlan(shiftStart, n, d, periodMin, charges, startCell, cycleOffset)
        if (p.error != null) { if (firstErr == null) firstErr = p.error; continue }
        list.add(Suggestion(d, p, max(0, p.maxDev - Rules.LEGAL)))
    }
    val sorted = list.sortedWith(
        compareBy<Suggestion>({ it.violation }, { it.plan.maxDev }, { it.plan.totalAbsDev },
            { it.plan.cycleStartError }, { abs(it.plan.cycleMin.toInt() - cycWant) }, { -it.d })
    )
    return Pair(sorted.take(5), if (sorted.isEmpty()) firstErr ?: "برنامه امکان‌پذیر نیست" else null)
}
