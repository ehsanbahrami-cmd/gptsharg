package ir.coke.discharge

import android.content.Context

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("plan", Context.MODE_PRIVATE)

    var periodText: String
        get() = sp.getString("period", "38") ?: "38"
        set(v) { sp.edit().putString("period", v).apply() }
    var dText: String
        get() = sp.getString("d", "30") ?: "30"
        set(v) { sp.edit().putString("d", v).apply() }
    var cycleText: String
        get() = sp.getString("cycle", "120") ?: "120"
        set(v) { sp.edit().putString("cycle", v).apply() }

    fun loadCharges(): Map<Int, Long> {
        val m = HashMap<Int, Long>()
        for (c in Rules.FIRST until Rules.FIRST + Rules.COUNT)
            if (sp.contains("c$c")) m[c] = sp.getLong("c$c", 0)
        return m
    }

    fun saveCharge(cell: Int, v: Long?) {
        val e = sp.edit()
        if (v == null) e.remove("c$cell") else e.putLong("c$cell", v)
        e.apply()
    }
}
