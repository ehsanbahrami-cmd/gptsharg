package ir.coke.discharge

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/** تاریخ شمسی + ساعت؛ زمان‌ها بر حسب دقیقه از epoch (منطقه زمانی تهران) */
object Dates {
    private val zone: ZoneId = ZoneId.of("Asia/Tehran")

    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm: Int
        val jd: Int
        if (days < 186) { jm = 1 + days / 31; jd = 1 + days % 31 }
        else { jm = 7 + (days - 186) / 30; jd = 1 + (days - 186) % 30 }
        return intArrayOf(jy, jm, jd)
    }

    private fun jalaliToGregorian(jyIn: Int, jm: Int, jd: Int): IntArray {
        val jy = jyIn + 1595
        var days = -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd +
            (if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) { gy += (days - 1) / 365; days = (days - 1) % 365 }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) { gd -= sal[gm]; gm++ }
        return intArrayOf(gy, gm, gd)
    }

    fun digits(s: String): String = buildString {
        for (ch in s.trim()) append(
            when (ch) {
                in '۰'..'۹' -> '0' + (ch - '۰')
                in '٠'..'٩' -> '0' + (ch - '٠')
                '٫', ',' -> '.'
                else -> ch
            }
        )
    }

    fun fa(s: String): String = buildString {
        for (ch in s) append(if (ch in '0'..'9') '۰' + (ch - '0') else ch)
    }

    fun toEpochMin(y: Int, m: Int, d: Int, hh: Int, mm: Int): Long {
        val g = jalaliToGregorian(y, m, d)
        return LocalDateTime.of(g[0], g[1], g[2], hh, mm).atZone(zone).toEpochSecond() / 60
    }

    fun fields(min: Long): IntArray {
        val z = Instant.ofEpochSecond(min * 60).atZone(zone)
        val j = gregorianToJalali(z.year, z.monthValue, z.dayOfMonth)
        return intArrayOf(j[0], j[1], j[2], z.hour, z.minute)
    }

    fun addDays(ymd: IntArray, k: Int): IntArray = fields(toEpochMin(ymd[0], ymd[1], ymd[2], 12, 0) + k * 1440L).copyOfRange(0, 3)

    fun fmtYmd(ymd: IntArray): String = fa("%04d/%02d/%02d".format(ymd[0], ymd[1], ymd[2]))

    fun nowMin(): Long = System.currentTimeMillis() / 60000

    fun fmtDate(min: Long): String {
        val f = fields(min)
        return fa("%04d/%02d/%02d".format(f[0], f[1], f[2]))
    }

    fun fmtTime(min: Long): String {
        val f = fields(min)
        return fa("%02d:%02d".format(f[3], f[4]))
    }

    fun fmtHM(totalMin: Long): String = fa("%d:%02d".format(totalMin / 60, totalMin % 60))

    fun parseDate(s: String): IntArray? {
        val p = digits(s).split('/', '-', '.')
        if (p.size != 3) return null
        val v = p.map { it.trim().toIntOrNull() ?: return null }
        if (v[0] !in 1300..1500 || v[1] !in 1..12 || v[2] !in 1..(if (v[1] <= 6) 31 else 30)) return null
        return intArrayOf(v[0], v[1], v[2])
    }

    fun parseTime(s: String): IntArray? {
        val p = digits(s).split(':')
        if (p.size != 2) return null
        val h = p[0].trim().toIntOrNull() ?: return null
        val m = p[1].trim().toIntOrNull() ?: return null
        if (h !in 0..23 || m !in 0..59) return null
        return intArrayOf(h, m)
    }
}
