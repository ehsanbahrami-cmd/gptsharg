package ir.coke.discharge

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class AppState(val store: Store) {
    var periodText by mutableStateOf(store.periodText)
    var dText by mutableStateOf(store.dText)
    var cycleText by mutableStateOf(store.cycleText)
    var version by mutableIntStateOf(0)
    val charges = mutableStateMapOf<Int, Long>().apply { putAll(store.loadCharges()) }

    var dateText by mutableStateOf(Dates.fmtDate(Dates.nowMin()))
    var kind by mutableStateOf(ShiftKind.EVENING)
    var startText by mutableStateOf("101")
    var tab by mutableIntStateOf(2)
    var countText by mutableStateOf("")
    var plan by mutableStateOf<Plan?>(null)
    var msg by mutableStateOf("")

    fun periodHours(): Double? = Dates.digits(periodText).toDoubleOrNull()?.takeIf { it > 0 }
    fun d(): Int? = Dates.digits(dText).toIntOrNull()?.takeIf { it >= Rules.MIN_GAP }
    fun cycleOffset(): Int = Dates.digits(cycleText).toIntOrNull() ?: 120

    /** تاریخ پیش‌فرض = اکنون منهای (پریود منهای ۷ ساعت و ۴۰ دقیقه کار شیفت) */
    fun defaultYmd(): IntArray {
        val ph = periodHours() ?: 8.0
        return Dates.fields(Dates.nowMin() - Math.round((ph - Rules.SHIFT_MIN / 60.0) * 60)).copyOfRange(0, 3)
    }

    fun shiftCellCount(): Int? {
        Dates.digits(countText).toIntOrNull()?.let { return it }
        val ph = periodHours() ?: return null
        return shiftCount(cellsPerDay(ph), kind)
    }

    fun startCell(): Int? = Dates.digits(startText).toIntOrNull()?.takeIf { it in Rules.FIRST until Rules.FIRST + Rules.COUNT }

    fun setCharge(cell: Int, v: Long?) {
        if (v == null) charges.remove(cell) else charges[cell] = v
        store.saveCharge(cell, v)
    }

    var minDText by mutableStateOf("10")
    var wantText by mutableStateOf("90")
    var suggestions by mutableStateOf<List<Suggestion>>(emptyList())

    private class Params(val s: Long, val n: Int, val d: Int?, val periodMin: Long, val start: Int?)

    private fun params(needD: Boolean): Params? {
        val ph = periodHours() ?: run { msg = "پریود را در تنظیمات وارد کنید"; return null }
        val d = d()
        if (needD && d == null) {
            val rawD = Dates.digits(dText).toIntOrNull()
            msg = if (rawD != null && rawD < Rules.MIN_GAP) "حداقل فاصله مجاز بین دو تخلیه ۱۰ دقیقه است" else "فاصله سلول‌ها را در تنظیمات وارد کنید"
            return null
        }
        val dd = Dates.parseDate(dateText) ?: run { msg = "تاریخ نامعتبر است (مثال ۱۴۰۵/۰۸/۲۷)"; return null }
        val mid = Dates.toEpochMin(dd[0], dd[1], dd[2], 0, 0)
        val startMinute = shiftStartMinute(Math.round(ph * 60), kind)
        val s = when (kind) {
            // تاریخ انتخابی برای شیفت شب، تاریخ پایان شیفت است؛ شروع آن روز قبل است.
            ShiftKind.NIGHT -> mid - 1440 + startMinute
            ShiftKind.DAY -> mid + startMinute
            ShiftKind.EVENING -> mid + startMinute
        }
        val n = Dates.digits(countText).toIntOrNull() ?: shiftCount(cellsPerDay(ph), kind)
        return Params(s, n, d, Math.round(ph * 60), Dates.digits(startText).toIntOrNull())
    }

    /** محاسبه با فاصله‌ای که اپراتور دستی وارد کرده است. */
    fun compute() {
        msg = ""
        plan = null
        val pr = params(true) ?: return
        val p = buildPlan(pr.s, pr.n, pr.d!!, pr.periodMin, charges, pr.start, cycleOffset())
        if (p.error != null) {
            msg = if (p.mismatch.isNotEmpty()) mismatchText(p) else p.error
        } else {
            plan = p
            tab = 3
        }
    }

    /** جست‌وجوی خودکار فاصله و ساخت برنامه با بهترین گزینه چندمعیاره. */
    fun optimizeAndCompute() {
        msg = ""
        plan = null
        suggestions = emptyList()
        val pr = params(false) ?: return
        val minGap = Dates.digits(minDText).toIntOrNull()?.coerceAtLeast(Rules.MIN_GAP) ?: Rules.MIN_GAP
        val wantedCycle = Dates.digits(wantText).toIntOrNull()?.coerceAtLeast(Rules.MIN_CYCLE) ?: 90
        val (options, error) = suggestD(
            pr.s, pr.n, pr.periodMin, charges, pr.start, cycleOffset(), minGap, wantedCycle
        )
        if (options.isEmpty()) {
            msg = error ?: "با محدودیت‌های این شیفت برنامه امکان‌پذیر نیست؛ اپراتور باید شرایط را بررسی کند."
            return
        }
        val best = options.first()
        dText = best.d.toString()
        store.dText = dText
        plan = best.plan
        suggestions = options
        tab = 3
        msg = if (best.violation > 0) {
            "بهترین برنامه با فاصله ${best.d} دقیقه پیدا شد؛ بیشترین تخطی از محدوده ±۳۰ دقیقه برابر ${best.plan.maxDev - Rules.LEGAL} دقیقه است. تصمیم نهایی با اپراتور است."
        } else {
            "بهترین برنامه با فاصله ${best.d} دقیقه پیدا شد؛ همه پریودها در محدوده مجاز قرار دارند."
        }
    }

    private fun fmtDT(m: Long) = Dates.fmtDate(m) + " " + Dates.fmtTime(m)

    private fun mismatchText(p: Plan): String {
        val sb = StringBuilder("⚠ تاریخ‌ها با پریود و شیفت انتخابی متناسب نیست؛ پریود منفی یا غیرواقعی می‌شود.\n")
        sb.append("بازه کار شیفت: ${fmtDT(p.shiftStart)} تا ${fmtDT(p.shiftStart + Rules.SHIFT_MIN)} (۴۶۰ دقیقه)\n")
        sb.append("فاصله تعویض شیفت: ${Rules.HANDOVER_MIN} دقیقه خارج از برنامه عملیاتی\n")
        p.mismatch.take(3).forEach { sb.append("سلول ${Dates.fa("${it.cell}")}: شارژ ${fmtDT(it.chargeMin)} ← موعد تخلیه ${fmtDT(it.idealMin)}\n") }
        if (p.mismatch.size > 3) sb.append("و ${Dates.fa("${p.mismatch.size - 3}")} سلول دیگر\n")
        sb.append("تاریخ شارژ سلول‌ها یا تاریخ و شیفت را اصلاح کنید.")
        return sb.toString()
    }

    fun shiftDate(k: Int) {
        val dd = Dates.parseDate(dateText) ?: Dates.fields(Dates.nowMin()).copyOfRange(0, 3)
        dateText = Dates.fmtYmd(Dates.addDays(dd, k))
    }

    fun suggest() {
        msg = ""
        suggestions = emptyList()
        val pr = params(false) ?: return
        val dMin = Dates.digits(minDText).toIntOrNull() ?: Rules.MIN_GAP
        val want = Dates.digits(wantText).toIntOrNull() ?: 90
        val (list, err) = suggestD(pr.s, pr.n, pr.periodMin, charges, pr.start, cycleOffset(), dMin, want)
        if (list.isEmpty()) msg = err ?: "پیشنهادی پیدا نشد"
        suggestions = list
    }

    fun chooseD(d: Int) {
        dText = d.toString()
        store.dText = dText
        suggestions = emptyList()
        compute()
    }

    fun applyPlan() {
        val p = plan ?: return
        for (r in p.rows) setCharge(r.cell, r.planMin)
        version++
        startText = nextCell(p.rows.last().cell).toString()
        countText = ""
        val dd = Dates.parseDate(dateText)
        when (kind) {
            ShiftKind.NIGHT -> kind = ShiftKind.DAY
            ShiftKind.DAY -> kind = ShiftKind.EVENING
            ShiftKind.EVENING -> { kind = ShiftKind.NIGHT; if (dd != null) dateText = Dates.fmtYmd(Dates.addDays(dd, 1)) }
        }
        msg = "اعمال شد؛ شیفت بعدی و سلول شروع بعدی تنظیم شد"
        plan = null
        tab = 2
    }

    private fun noteText(p: Plan): String = when (p.note) {
        Note.OK -> ""
        Note.CYCLE_REDUCED -> "زمان سیکل برای رعایت ±۳۰ دقیقه از مقدار فرمول (${p.nominalCycle} دقیقه) کم شد."
        Note.EARLY -> "برای حفظ برنامه شیفت، بعضی سلول‌ها بیش از ۳۰ دقیقه زودتر از موعد تخلیه می‌شوند (حداکثر انحراف ${p.maxDev} دقیقه)."
        Note.LATE -> "برای حفظ برنامه شیفت، بعضی سلول‌ها بیش از ۳۰ دقیقه دیرتر از موعد تخلیه می‌شوند (حداکثر انحراف ${p.maxDev} دقیقه)."
        Note.BOTH -> "برای حفظ برنامه شیفت، از محدوده ±۳۰ دقیقه در هر دو جهت تخطی شده است (حداکثر انحراف ${p.maxDev} دقیقه)."
    }

    private fun periodCell(r: Row): String {
        val dev = r.devMin
        return Dates.fmtHM(r.periodMin) + if (kotlin.math.abs(dev) > Rules.LEGAL) " (" + Dates.fa(if (dev > 0) "+$dev" else "$dev") + ")" else ""
    }

    fun reportHtml(): String {
        val p = plan ?: return ""
        val sb = StringBuilder()
        sb.append("<html dir='rtl'><head><meta charset='utf-8'><style>")
        sb.append("body{font-family:sans-serif;margin:16px}h2{text-align:center;margin:4px}p{margin:4px;text-align:center}")
        sb.append("table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #000;padding:7px;text-align:center;font-size:14px}")
        sb.append("th{background:#ddd}.cy{background:#cfe3ff;font-weight:bold}.bad{background:#ffe0e0}")
        sb.append("</style></head><body>")
        sb.append("<h2>برنامه تخلیه و شارژ باتری</h2>")
        sb.append("<p>شیفت ${kind.fa} — تاریخ ${Dates.fa(dateText)}</p>")
        sb.append("<p>مدت کار: ۴۶۰ دقیقه — فاصله تعویض شیفت: ۲۰ دقیقه (خارج از برنامه)</p>")
        sb.append("<p>تعداد سلول: ${Dates.fa("${p.n}")} — فاصله سلول‌ها: ${Dates.fa("${d()}")} دقیقه — پریود: ${Dates.fa(periodText)} ساعت</p>")
        sb.append("<table><tr><th>ردیف</th><th>شماره سلول</th><th>زمان تخلیه</th><th>زمان شارژ</th><th>پریود</th><th>آمپراژ</th></tr>")
        p.rows.forEachIndexed { i, r ->
            val bad = kotlin.math.abs(r.devMin) > Rules.LEGAL
            sb.append("<tr${if (bad) " class='bad'" else ""}><td>${Dates.fa("${i + 1}")}</td><td>${Dates.fa("${r.cell}")}</td>")
            sb.append("<td>${Dates.fmtTime(r.planMin)}</td><td></td><td>${periodCell(r)}</td><td></td></tr>")
            if (i == p.cycleAfter) sb.append("<tr class='cy'><td colspan='6'>سیکل (تعمیرات): ${Dates.fmtTime(r.planMin)} تا ${Dates.fmtTime(p.rows[i + 1].planMin)} (${Dates.fa("${p.cycleMin}")} دقیقه)</td></tr>")
        }
        sb.append("</table>")
        val nt = noteText(p)
        if (nt.isNotEmpty()) sb.append("<p>$nt</p>")
        sb.append("</body></html>")
        return sb.toString()
    }

    fun shareText(): String {
        val p = plan ?: return ""
        val sb = StringBuilder()
        sb.append("برنامه تخلیه ${kind.fa} ${dateText}\n")
        p.rows.forEachIndexed { i, r ->
            sb.append("${i + 1}) سلول ${r.cell}  ${Dates.fmtTime(r.planMin)}  پریود ${periodCell(r)}\n")
            if (i == p.cycleAfter) sb.append("   — سیکل ${Dates.fmtTime(r.planMin)} تا ${Dates.fmtTime(p.rows[i + 1].planMin)} —\n")
        }
        return sb.toString()
    }

    fun noteForUi(p: Plan) = noteText(p)
}

var printView: WebView? = null

fun printReport(ctx: Context, html: String) {
    val wv = WebView(ctx)
    printView = wv
    wv.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print("برنامه تخلیه", view.createPrintDocumentAdapter("discharge_plan"), PrintAttributes.Builder().build())
        }
    }
    wv.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = AppState(Store(this))
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App(st) }
                }
            }
        }
    }
}

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0B5FA5), onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E8FF), onPrimaryContainer = Color(0xFF00315C),
    secondary = Color(0xFFE67E00), tertiary = Color(0xFF00897B),
    background = Color(0xFFF3F6FA), onBackground = Color(0xFF16202A),
    surface = Color.White, onSurface = Color(0xFF16202A),
    surfaceVariant = Color(0xFFE4EAF2), onSurfaceVariant = Color(0xFF42505E),
    outline = Color(0xFF8A97A4), error = Color(0xFFC62828),
    errorContainer = Color(0xFFFFDAD6), onErrorContainer = Color(0xFF410002),
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8AB8FF), onPrimary = Color(0xFF00315C),
    primaryContainer = Color(0xFF16406E), onPrimaryContainer = Color(0xFFD6E8FF),
    secondary = Color(0xFFFFB454), tertiary = Color(0xFF4DD0C0),
    background = Color(0xFF0E141B), onBackground = Color(0xFFE6EDF4),
    surface = Color(0xFF17212C), onSurface = Color(0xFFE6EDF4),
    surfaceVariant = Color(0xFF263444), onSurfaceVariant = Color(0xFFB9C5D2),
    outline = Color(0xFF6B7885), error = Color(0xFFFF8A80),
    errorContainer = Color(0xFF5C1A1A), onErrorContainer = Color(0xFFFFDAD6),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkScheme else LightScheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}

@Composable
fun Header(title: String, subtitle: String) {
    val c = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.horizontalGradient(listOf(c.primary.copy(alpha = 0.95f), c.tertiary)))
            .padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Column {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.White.copy(alpha = 0.88f), fontSize = 13.sp)
        }
    }
}

@Composable
fun App(st: AppState) {
    val titles = listOf(
        "تنظیمات" to "پریود، فاصله سلول‌ها و سیکل",
        "ثبت شارژ سلول‌ها" to "زمان آخرین شارژ هر سلول",
        "برنامه شیفت" to "انتخاب شیفت و محاسبه",
        "گزارش" to "جدول تخلیه و شارژ"
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { Header(titles[st.tab].first, titles[st.tab].second) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf("تنظیمات", "سلول‌ها", "برنامه", "گزارش").forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = st.tab == i, onClick = { st.tab = i },
                        icon = { Text(listOf("⚙", "🔋", "📅", "🧾")[i], fontSize = 20.sp) },
                        label = { Text(t, fontSize = 12.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (st.tab) {
                0 -> SettingsScreen(st)
                1 -> CellsScreen(st)
                2 -> PlanScreen(st)
                else -> ReportScreen(st)
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 15.sp)
            content()
        }
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier.fillMaxWidth(), kb: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = kb), modifier = modifier
    )
}

@Composable
fun MiniBtn(t: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = Modifier.size(44.dp), contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(12.dp)) {
        Text(t, fontSize = 20.sp)
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

fun chipLabel(k: ShiftKind) = when (k) {
    ShiftKind.NIGHT -> "🌙 شب"
    ShiftKind.DAY -> "☀ روز"
    ShiftKind.EVENING -> "🌆 عصر"
}

@Composable
fun ShiftChips(st: AppState) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (k in listOf(ShiftKind.NIGHT, ShiftKind.DAY, ShiftKind.EVENING)) {
            FilterChip(selected = st.kind == k, onClick = { st.kind = k }, label = { Text(chipLabel(k)) })
        }
    }
}

@Composable
fun ErrorCard(text: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Text(text, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
    }
}

@Composable
fun SettingsScreen(st: AppState) {
    Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("پریود و فاصله") {
            Field(st.periodText, { st.periodText = it; st.store.periodText = it }, "پریود تولید کک (ساعت)", kb = KeyboardType.Decimal)
            Field(st.dText, { st.dText = it; st.store.dText = it }, "فاصله سلول‌ها (دقیقه بین دو تخلیه)", kb = KeyboardType.Number)
        }
        Section("سیکل و پیشنهاد") {
            Field(st.cycleText, { st.cycleText = it; st.store.cycleText = it }, "محل شروع سیکل (دقیقه پس از شروع ۴۶۰ دقیقه کار شیفت)", kb = KeyboardType.Number)
            Field(st.minDText, { st.minDText = it }, "کمترین فاصله برای جست‌وجو (حداقل ۱۰ دقیقه)", kb = KeyboardType.Number)
            Text("موتور تمام فاصله‌ها را از حداقل ۱۰ دقیقه تا بیشترین مقدار سازگار با سیکل ۶۰ دقیقه‌ای بررسی می‌کند.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Field(st.wantText, { st.wantText = it }, "سیکل مطلوب برای پیشنهاد (دقیقه)", kb = KeyboardType.Number)
        }
        val ph = st.periodHours()
        if (ph != null) {
            val n = cellsPerDay(ph)
            Section("خلاصه محاسبه") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("سلول در شبانه‌روز", Dates.fa("$n"), Modifier.weight(1f))
                    Stat("🌙 شب", Dates.fa("${shiftCount(n, ShiftKind.NIGHT)}"), Modifier.weight(1f))
                    Stat("☀ روز", Dates.fa("${shiftCount(n, ShiftKind.DAY)}"), Modifier.weight(1f))
                    Stat("🌆 عصر", Dates.fa("${shiftCount(n, ShiftKind.EVENING)}"), Modifier.weight(1f))
                }
                val d = st.d()
                if (d != null) {
                    for (k in ShiftKind.values()) {
                        val c = shiftCount(n, k)
                        val cyc = Rules.USABLE - (c - 2) * d
                        val low = cyc < Rules.MIN_CYCLE
                        Text(
                            Dates.fa("زمان سیکل ${k.fa.substringBefore(' ')}: $cyc دقیقه" + if (low) " (کمتر از ۶۰؛ فاصله سلول‌ها را کم کنید)" else ""),
                            color = if (low) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface, fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CellsScreen(st: AppState) {
    val n = st.shiftCellCount()
    val start = st.startCell()
    val cells = if (n != null && start != null && n in 1..Rules.COUNT) chain(start, n) else emptyList()
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Section("شیفت و اولین سلول") {
                ShiftChips(st)
                Field(st.startText, { st.startText = it }, "اولین سلول شیفت (مثلاً ۱۰۱ یا ۱۰۵)", kb = KeyboardType.Number)
                Text(
                    if (cells.isEmpty()) "پریود را در تنظیمات و سلول شروع را درست وارد کنید"
                    else Dates.fa("${cells.size} سلول: " + cells.joinToString("، ")),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(cells, key = { it }) { cell -> CellRow(st, cell) }
    }
}

@Composable
fun Picker(label: String, value: String, options: List<String>, onPick: (Int) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text(if (value.isEmpty()) label else value, fontSize = 16.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(i); open = false }) }
        }
    }
}

@Composable
fun CellRow(st: AppState, cell: Int) {
    val cur = st.charges[cell]
    var ymd by remember(st.version, st.periodText) {
        mutableStateOf(cur?.let { Dates.fields(it).copyOfRange(0, 3) } ?: st.defaultYmd())
    }
    var hh by remember(st.version) { mutableStateOf<Int?>(cur?.let { Dates.fields(it)[3] }) }
    var mm by remember(st.version) { mutableStateOf<Int?>(cur?.let { Dates.fields(it)[4] }) }
    fun commit() {
        if (hh != null || mm != null)
            st.setCharge(cell, Dates.toEpochMin(ymd[0], ymd[1], ymd[2], hh ?: 0, mm ?: 0))
    }
    val ph = st.periodHours()
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 12.dp, vertical = 6.dp)
                ) { Text(Dates.fa("$cell"), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                Text(Dates.fmtYmd(ymd), Modifier.weight(1f), fontSize = 17.sp, textAlign = TextAlign.Center)
                MiniBtn("−") { ymd = Dates.addDays(ymd, -1); commit() }
                MiniBtn("+") { ymd = Dates.addDays(ymd, 1); commit() }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Picker("ساعت", hh?.let { Dates.fa("%02d".format(it)) } ?: "", (0..23).map { Dates.fa("%02d".format(it)) },
                    { hh = it; commit() }, Modifier.weight(1f))
                Picker("دقیقه", mm?.let { Dates.fa("%02d".format(it)) } ?: "", (0..59).map { Dates.fa("%02d".format(it)) },
                    { mm = it; commit() }, Modifier.weight(1f))
                TextButton(onClick = { hh = null; mm = null; st.setCharge(cell, null) }) { Text("پاک") }
            }
            if (cur != null && ph != null) {
                val ideal = cur + Math.round(ph * 60)
                Text(
                    "موعد تخلیه: ${Dates.fmtDate(ideal)} ${Dates.fmtTime(ideal)}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (cur != null && cur > Dates.nowMin() + 5)
                Text("⚠ تاریخ شارژ در آینده است؛ تاریخ را بررسی کنید", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
fun PlanScreen(st: AppState) {
    Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("شیفت") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(st.dateText, { st.dateText = it }, "تاریخ شیفت (شمسی)", Modifier.weight(1f))
                MiniBtn("−") { st.shiftDate(-1) }
                MiniBtn("+") { st.shiftDate(1) }
            }
            ShiftChips(st)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(st.startText, { st.startText = it }, "سلول شروع", Modifier.weight(1f), KeyboardType.Number)
                Field(st.countText, { st.countText = it }, "تعداد سلول (خالی = خودکار)", Modifier.weight(1f), KeyboardType.Number)
            }
        }
        Button(onClick = { st.optimizeAndCompute() }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
            Text("بهینه‌سازی و محاسبه برنامه", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(onClick = { st.compute() }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
            Text("محاسبه با فاصله دستی واردشده")
        }
        OutlinedButton(onClick = { st.suggest() }, Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(16.dp)) {
            Text("نمایش گزینه‌های جایگزین فاصله")
        }
        for (sg in st.suggestions) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        Dates.fa("فاصله ${sg.d} دقیقه: سیکل ${sg.plan.cycleMin} دقیقه، " +
                            if (sg.violation == 0) "پریود بدون خطا (حداکثر انحراف ${sg.plan.maxDev} دقیقه)" else "تخطی از ±۳۰ تا ${sg.plan.maxDev} دقیقه"),
                        Modifier.weight(1f), fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Button(onClick = { st.chooseD(sg.d) }, shape = RoundedCornerShape(12.dp)) { Text("انتخاب") }
                }
            }
        }
        if (st.msg.isNotEmpty()) ErrorCard(st.msg)
    }
}

@Composable
fun ReportScreen(st: AppState) {
    val ctx = LocalContext.current
    val p = st.plan
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (p == null) {
            Section("گزارش") { Text("ابتدا در صفحه «برنامه» دکمه «محاسبه برنامه» را بزنید.") }
        } else {
            Text(
                Dates.fa("شیفت ${st.kind.fa} — ${st.dateText}"),
                fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat("تعداد سلول", Dates.fa("${p.n}"), Modifier.weight(1f))
                Stat("فاصله سلول‌ها", Dates.fa("${st.d()} د"), Modifier.weight(1f))
                Stat("سیکل", Dates.fa("${p.cycleMin} د"), Modifier.weight(1f))
                Stat("بیشترین انحراف", Dates.fa("${p.maxDev} د"), Modifier.weight(1f))
            }
            if (st.msg.isNotEmpty()) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text(st.msg, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSecondaryContainer, fontSize = 13.sp)
                }
            }
            val nt = st.noteForUi(p)
            if (nt.isNotEmpty()) ErrorCard(nt)
            if (st.suggestions.size > 1) {
                Section("گزینه‌های جایگزین موتور") {
                    st.suggestions.drop(1).forEach { sg ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                Dates.fa("فاصله ${sg.d} دقیقه — سیکل ${sg.plan.cycleMin} دقیقه — بیشترین انحراف ${sg.plan.maxDev} دقیقه"),
                                Modifier.weight(1f), fontSize = 12.sp
                            )
                            TextButton(onClick = { st.chooseD(sg.d) }) { Text("انتخاب") }
                        }
                    }
                }
            }
            if (p.skipped.isNotEmpty())
                ErrorCard("هشدار: سلول‌های عقب‌مانده در این شیفت نیامده‌اند: " + p.skipped.joinToString("، ") { Dates.fa("$it") } +
                    " (سلول شروع یا تعداد سلول را تغییر دهید)")
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(Modifier.padding(6.dp)) {
                    TRow(listOf("ردیف", "شماره سلول", "زمان تخلیه", "زمان شارژ", "پریود", "آمپراژ"), header = true)
                    p.rows.forEachIndexed { i, r ->
                        val bad = kotlin.math.abs(r.devMin) > Rules.LEGAL
                        TRow(
                            listOf(
                                Dates.fa("${i + 1}"), Dates.fa("${r.cell}"), Dates.fmtTime(r.planMin), "",
                                Dates.fmtHM(r.periodMin) + if (bad) Dates.fa(if (r.devMin > 0) " (+${r.devMin})" else " (${r.devMin})") else "", ""
                            ),
                            bad = bad
                        )
                        if (i == p.cycleAfter) {
                            Box(
                                Modifier.fillMaxWidth().border(0.5.dp, MaterialTheme.colorScheme.outline)
                                    .background(MaterialTheme.colorScheme.primaryContainer).padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "سیکل (تعمیرات): ${Dates.fmtTime(r.planMin)} تا ${Dates.fmtTime(p.rows[i + 1].planMin)}  (${Dates.fa("${p.cycleMin}")} دقیقه)",
                                    fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }
            Button(onClick = { printReport(ctx, st.reportHtml()) }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("چاپ / ذخیره PDF") }
            OutlinedButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, st.shareText()) }
                ctx.startActivity(Intent.createChooser(i, "اشتراک‌گذاری برنامه"))
            }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) { Text("اشتراک‌گذاری متن برنامه") }
            OutlinedButton(onClick = { st.applyPlan() }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
                Text("اعمال برنامه (ثبت تخلیه‌ها به‌عنوان شارژ جدید)")
            }
        }
    }
}

@Composable
fun TRow(cols: List<String>, header: Boolean = false, bad: Boolean = false) {
    val c = MaterialTheme.colorScheme
    val w = listOf(0.6f, 1f, 1.2f, 1.1f, 1.6f, 1f)
    val bg = if (header) c.surfaceVariant else if (bad) c.errorContainer else Color.Transparent
    val fg = if (bad) c.onErrorContainer else c.onSurface
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        cols.forEachIndexed { i, t ->
            Box(
                Modifier.weight(w[i]).fillMaxHeight().border(0.5.dp, c.outline).background(bg).padding(vertical = 9.dp, horizontal = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    t, color = fg, fontWeight = if (header || i == 1 || i == 2) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 13.sp, textAlign = TextAlign.Center
                )
            }
        }
    }
}
